# TweakScale Companion :: Living Style :: Change Log

* 2020-0907: 0.0.2.1 (LisiasT) for KSP >= 1.2.2
	+ Adds support for:
		- CxAerospace Station Parts 
	+ Fix some packaging issues.
* 2020-0906: 0.0.2.0 (LisiasT) for KSP >= 1.2.2
	+ **Withdrawn** 
* 2020-0806: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ Initial Public Release
	+ Adds support for:
		- HabTech
		- HabTech2
		- Tokamak Industries (and PorkJet's HabPack)
  
