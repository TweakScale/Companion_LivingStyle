# TweakScale Companion :: Living Style :: Known Issues

* Parts using Module Centrifuge may not scale too well for bigger sizes
	+ The scaling exponent used kinda works, but it's not perfect. A new solution for scaling the RPM is needed (in the same way I made for the Module KIS Inventory, I think) 
