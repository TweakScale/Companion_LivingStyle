# TweakScale Companion :: Living Style :: Change Log

* 2020-0806: 0.0.1.0 (LisiasT) for KSP >= 1.2.2
	+ Initial Public Release
	+ Adds support for:
		- HabTech
		- HabTech2
		- Tokamak Industries (and PorkJet's HabPack)
  
